# Object Detection > 2024-12-12 9:51pm
https://universe.roboflow.com/crops-disease/object-detection-og9pn

Provided by a Roboflow user
License: CC BY 4.0

